# Online-Fruit-Shop
E-Commerce fruit selling site using html, css and javascript

**Live site -** [https://online-fruit-shop.netlify.app/](https://online-fruit-shop.netlify.app/)

## Preview
![img01](https://user-images.githubusercontent.com/83011210/228267470-b661113e-275d-4206-9dd7-f831647de0b2.png)
![img02](https://user-images.githubusercontent.com/83011210/227763794-eb2efe5e-e39e-4de0-a5b9-40b7c1836673.png)
![img03](https://user-images.githubusercontent.com/83011210/227763808-c53a9467-5b82-4e63-bb34-3bd89328f609.png)
![img04](https://user-images.githubusercontent.com/83011210/227763818-1d9b2699-0a68-4516-afca-b489b14787f7.png)
![img05](https://user-images.githubusercontent.com/83011210/227763823-36af0939-cb71-44d5-b0b7-6fa4fc2de20e.png)
![img06](https://user-images.githubusercontent.com/83011210/227763840-b5a941f9-6c9e-4c00-a3cf-379624b3ff68.png)
![img07](https://user-images.githubusercontent.com/83011210/227763846-eae36570-1599-49ff-884e-b37e0fd9664d.png)
![mdle](https://user-images.githubusercontent.com/83011210/228267781-f0bcc309-b4a3-4350-8c76-aa5d6f47bf5d.png)
![lst01](https://user-images.githubusercontent.com/83011210/228267868-440301b8-51a7-4e56-8de7-97997ccd334b.png)

